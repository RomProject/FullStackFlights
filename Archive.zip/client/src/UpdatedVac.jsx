import React from 'react'

export default function UpdatedVac() {
    return (
        <div>
            
        </div>
    )
}
